import React, { useState } from 'react';
import Slide from '../components/Slide';

export default function ProductCode() {
    const uomOptions = ["Bsg's", 'CFT', 'N/A', "Mtr's", "No's", "Kg's", "Ltr"];

    const [pic, setPic] = useState()
    const handleFileChange = (e) => {
        const file = e.target.files[0];
        if (file) {
            // Display the selected image
            const reader = new FileReader();
            reader.onload = (event) => {
                setPic(event.target.result);
            };
            reader.readAsDataURL(file);
        }
    };

    const [isFormVisible, setIsFormVisible] = useState(true);

    const toggleFormVisibilitys = () => {
        setIsFormVisible(!isFormVisible);
    };

    const [isFormVisibles, setIsFormVisibles] = useState(false);

    const toggleFormVisibilities = () => {
        setIsFormVisibles(!isFormVisibles);
    };



    return (
        <div className="row mt-3 mb-5  ">
            <div className="col-3">
                <Slide />
            </div >
            <div className='col-9'>
                <div className="col-8 mx-2  ">
                    <span style={{ fontWeight: 'bold' }} className='fs-3'>INVENTORY</span><span>/</span>
                    <span style={{ fontWeight: 'bold' }} className='fs-4'>SETUP</span><span>/</span>
                    <span className='fs-5 fw-bold'>PRODUCT Code</span>

                </div>
                <div className='row'>
                    <div className="col border rounded mt-3 mb-5">
                        <span className='mt-2'>Product Code</span>
                        <input type="text" className='w-25 mt-2' />

                        <span className='ms-2'>UOM</span>
                        <select style={{ width: '146px', marginLeft: '20px' }}>
                            <option value=""></option>
                            {uomOptions.map((item, index) => (
                                <option value={item} key={index}>
                                    {item}
                                </option>
                            ))}
                        </select>

                        <span >Is Active</span>
                        <input type="checkbox" className='mx-3' />

                        <span className='' style={{ marginLeft: '10px' }}>Product Name</span>
                        <input type='txet' style={{ marginLeft: '17px', width: '600px' }} />

                        <span style={{ marginLeft: '207px' }}>Costing Allow</span>
                        <input type="checkbox" className='mx-3' />

                        <span style={{ marginLeft: '32px' }}>Description</span>
                        <input type="text" style={{ marginLeft: '16px', width: '600px' }} />
                        <span style={{ margin: '47px' }}>Category</span>
                        <input type="text" style={{ marginLeft: '-29px', width: '600px' }} />
                        <br />
                        <br />

                        <span style={{ marginLeft: '43px' }}>Company</span>
                        <input type="text" style={{ marginLeft: '18px' }} />
                        <span style={{ marginLeft: '155px' }}>Color</span>
                        <input type="text" style={{ marginLeft: '20px' }} />


                        <span style={{ marginLeft: '70px' }}>Brand</span>
                        <input type="text" style={{ marginLeft: '17px' }} />

                        <span style={{ marginLeft: '165px' }}>Size</span>
                        <input type="text" style={{ marginLeft: '20px' }} />

                    </div>
                    <div className="col border rounded ms-2 mt-3" >
                        {pic && <img src={pic} alt="Uploaded"  />}
                        <input type='file' placeholder='sdfghj' className='absolute rounded mt-auto' style={{ background: '#00ACFF', width: '200px', color: 'white', height: '40px',border: '5px solid #00ACFF' }} onChange={handleFileChange} />
                    </div>
                </div>

                <br />
                <div className="col-12 mb-3 " style={{ marginTop: '-50px' }}>
                    {/* <Link to={"/packingInfo"} style={{ background: '#00ACFF',width:'200px', color: 'white',  height: '40px', marginTop:'15px', border:'5px solid #00ACFF',borderRadius:'5px' }}>Packing Information</Link> */}

                    <button onClick={toggleFormVisibilitys} style={{ marginLeft: '10px', background: '#00ACFF', width: '200px', color: 'white', height: '40px', marginTop: '15px', border: '5px solid #00ACFF', borderRadius: '5px' }}>Packing Information</button>

                    <button onClick={toggleFormVisibilities} style={{ marginLeft: '10px', background: '#00ACFF', width: '200px', color: 'white', height: '40px', marginTop: '15px', border: '5px solid #00ACFF', borderRadius: '5px' }}>Product Specs and Rates</button>

                </div>
                <br />
                {
                    isFormVisible && <div className="row border" style={{ marginTop: '-20px ' }}>
                        <div className="col-4 border mx-4 flex rounded-3 mt-4 mb-4">
                            <br />
                            <span className='' style={{ marginLeft: '50px' }}>Pieces Per Unit</span>
                            <input type="text" style={{ marginLeft: '20px', width: '200px' }} />
                            <br />
                            <br />

                            <span style={{ marginLeft: '39px' }}>Units Per Carton</span>
                            <input type='text' style={{ marginLeft: '20px', width: '200px' }} />
                            <br />
                            <br />

                            <span style={{ marginLeft: '42px' }}>CBM Per Carton</span>
                            <input type="text" style={{ marginLeft: '20px', width: '200px' }} />
                            <br />
                            <br />

                            <span style={{ marginLeft: '92px' }}>HS Code</span>
                            <input type="text" style={{ marginLeft: '20px', width: '200px' }} />
                            <br />
                            <br />

                        </div>


                        <div className="col-4 border mt-4 mb-4 flex rounded-3 ">
                            <br />

                            <span className='' style={{ marginLeft: '50px' }}>Carton Length</span>
                            <input type="text" style={{ marginLeft: '20px', width: '200px' }} />
                            <br />
                            <br />

                            <span style={{ marginLeft: '43px' }}>Carton Breadth</span>
                            <input type='text' style={{ marginLeft: '20px', width: '200px' }} />
                            <br />
                            <br />

                            <span style={{ marginLeft: '50px' }}>Carton Height</span>
                            <input type="text" style={{ marginLeft: '20px', width: '200px' }} />
                            <br />
                            <br />

                        </div>


                        <div className="col-4 mt-4 mb-5 flex rounded-3 border " style={{ width: '400px', marginLeft: '10px', height: '200px' }}>
                            <br />
                            <br />
                            <span className='' style={{ marginLeft: '10px' }}>Gross Weight</span>
                            <input type="text" style={{ marginLeft: '20px', width: '200px' }} />
                            <br />
                            <br />

                            <span style={{ marginLeft: '25px' }}>Net Weight</span>
                            <input type='text' style={{ marginLeft: '20px', width: '200px' }} />
                            <br />
                            <br />

                            <input type="checkbox" name="" id="" style={{ marginLeft: '125px' }} />
                            <span style={{ marginLeft: '10px' }}>Fair Packing</span> <br />



                        </div>

                    </div>
                }

                <br />
                {
                    isFormVisibles && <div className="row mx-2">
                        <div className="col-4 border flex rounded-3  ">
                            <p style={{ marginTop: '-15px', border: 'none', color: '#00acff' }}>Stock Location</p>
                            <br />
                            <span className='' style={{ marginLeft: '52px' }}>Barcode 1 </span>
                            <input type="text" style={{ marginLeft: '20px', width: '250px' }} />
                            <br />
                            <br />

                            <span style={{ marginLeft: '52px' }}>Barcode 2</span>
                            <input type='text' style={{ marginLeft: '25px', width: '250px' }} />
                            <br />
                            <br />

                            <span style={{ marginLeft: '52px' }}>Barcode 3</span>
                            <input type="text" style={{ marginLeft: '25px', width: '250px' }} />
                            <br />
                            <br />

                            <span style={{ marginLeft: '72px' }}>Bundle</span>
                            <input type="text" style={{ marginLeft: '27px', width: '250px' }} />
                            <br />
                            <p style={{ marginLeft: '65px', marginTop: '-10px' }}>Barcode</p>
                            <br />

                        </div>


                        <div className="col-3 border flex rounded-3 mx-2 ">
                            <p style={{ marginTop: '-15px', border: 'none', color: '#00acff' }}>Stock Levels</p>

                            <br />

                            <span className='' style={{ marginLeft: '10px' }}>Reorder Level</span>
                            <input type="text" style={{ marginLeft: '10px', width: '200px' }} />
                            <br />
                            <br />

                            <span style={{ marginLeft: '-4px' }}>Minimum Stock</span>
                            <input type='text' style={{ marginLeft: '10px', width: '200px' }} />
                            <br />
                            <br />

                            <span style={{ marginLeft: '-6px' }}>Maximum Stock</span>
                            <input type="text" style={{ marginLeft: '10px', width: '200px' }} />
                            <br />
                            <br />

                            <span style={{ marginLeft: '27px' }}>Expiry Date</span>
                            <input type="text" style={{ marginLeft: '10px', width: '200px' }} />
                            <br />
                            <br />

                        </div>


                        <div className="col-4 border flex rounded-3 ">
                            <p style={{ marginTop: '-15px', border: 'none', color: '#00acff' }}>Product Rate's (RS) - Store</p>

                            <br />

                            <span className='' style={{ marginLeft: '10px' }}>Product Stock</span>
                            <input type="text" style={{ marginLeft: '10px', width: '150px' }} />
                            <br />
                            <br />

                            <span style={{ marginLeft: '45px' }}>Avg Rate</span>
                            <input type='text' style={{ marginLeft: '10px', width: '150px' }} />
                            <br />
                            <br />

                            <span style={{ marginLeft: '0px' }}>Until Sale Value</span>
                            <input type='text' style={{ marginLeft: '9px', width: '150px' }} />

                            <br /> <br />

                            {/* <span>Bundle</span>
    <input type='text' />
    <p>Sale Rate</p> */}



                            <span style={{ marginLeft: '8px' }}>Until Purchase</span>
                            <input type='text' style={{ marginLeft: '10px', width: '150px' }} />
                            <br />
                            <p style={{ marginLeft: '8px', marginTop: '-13px' }}>Rate</p>



                            <span style={{ marginLeft: '54px' }}>Profit %</span>
                            <input type='text' style={{ marginLeft: '10px', width: '150px' }} />
                            <br /><br />




                            <span style={{ marginLeft: '25px' }}>Discoun15%</span>
                            <input type='text' style={{ marginLeft: '10px', width: '150px' }} />
                            <br />
                            <br />


                        </div>

                        <div className="col-3 border" style={{ marginLeft: '1160px', marginTop: '-250px', width: '180px', height: '140px' }}>

                            <span style={{ marginLeft: '5px', fontSize: '15px' }}>Bundle</span>
                            <input type="text" style={{ width: '90px', marginLeft: '10px', marginTop: '10px' }} />
                            <p style={{ marginLeft: '-5px', marginTop: '-10px', fontSize: '15px' }}>Sale Rate</p>

                            <span style={{ marginLeft: '5px', fontSize: '15px' }}>Bundle</span>
                            <input type="text" style={{ width: '90px', marginLeft: '10px', marginTop: '10px' }} />
                            <p style={{ marginLeft: '-5px', marginTop: '-10px', fontSize: '15px' }}>Pur. Rate</p>

                        </div>
                        <div className=' border  mb-1'>
                            <button style={{ background: '#00ACFF', color: 'white', height: '40px', marginTop: '15px', marginLeft: '1120px', border: '5px solid #00ACFF', borderRadius: '5px' }}><i className="fa-solid fa-check"></i> Submit</button>
                            <button style={{ background: '#00ACFF', color: 'white', height: '40px', margin: '10px', marginLeft: '40px', border: '5px solid #00ACFF', borderRadius: '5px' }}><i className="fa-solid fa-circle-xmark"></i> Cancel</button>
                        </div>
                    </div>
                }

            </div>


        </div>
    );
}











































































































































// import React from 'react'
// import Slide from '../components/Slide'

// export default function ProductCode() {
//     const [pic, setPic] = useState()
//     const handleFileChange = (e) => {
//         const file = e.target.files[0];
//         if (file) {
//             // Display the selected image
//             const reader = new FileReader();
//             reader.onload = (event) => {
//                 setPic(event.target.result);
//             };
//             reader.readAsDataURL(file);
//         }
//     };
//     const [isFormVisible, setIsFormVisible] = useState(true);
//     const toggleFormVisibilitys = () => {
//         setIsFormVisible(!isFormVisible);
//     };
//     const [isFormVisibles, setIsFormVisibles] = useState(false);
//     const toggleFormVisibilities = () => {
//         setIsFormVisibles(!isFormVisibles);
//     };

//     return (
//         <div className='row'>
//             <div className='col'>
//                 <Slide />
//             </div>
//             <div className='col'>
//                 <span className='fs-3'>INVENTORY/</span><span className='fs-4'>SETUP/</span><span className='fs-5 fw-bold'>PRODUCT Code</span>
//                 <div className='row'>
//                     <div className="col-9 border rounded  mx-3 mt-3 mb-5">

//                         <span className='mx-3'>Product Code</span>
//                         <input type="text" className='w-25' />

//                         <span className='ms-3' >UOM</span>
//                         <select >
//                             <option value="Bsg's">Bsg's</option>
//                             <option value="CFT">CFT</option>
//                             <option value="N/A">N/A</option>
//                             <option value="Mtr's">Mtr's</option>
//                             <option value="Kg's">Kg's</option>
//                             <option value="Ltr">Ltr</option>
//                         </select>
//                         <span className='ms-1'>Is Active</span>
//                         <input type="checkbox" className='mx-3' />
//                         <span className='ms-1'>Costing Allow</span>
//                         <input type="checkbox" className='mx-3' />

//                         <span className='' >Product Name</span>
//                         <input type='text' />
//                         <span >Description</span>
//                         <input type="text" />
//                         <span >Category</span>
//                         <input type="text" />

//                         <span >Company</span>
//                         <input type="text" />
//                         <span >Color</span>
//                         <input type="text" />

//                         <span >Brand</span>
//                         <input type="text" />

//                         <span >Size</span>
//                         <input type="text" />

//                     </div>
//                     <div className="col-3 border mb-5  mx-2 rounded" >
//                         {pic && <img src={pic} alt="Uploaded" />}
//                         <input type='file' placeholder='sdfghj' className='absolute' onChange={handleFileChange} />

//                     </div>
//                 </div>
//                 <div className='row'>
//                     <div className="col-12 mb-3 " style={{ marginTop: '-50px' }}>
//                         <button onClick={toggleFormVisibilitys} >Packing Information</button>
//                         <button onClick={toggleFormVisibilities} >Product Specs and Rates</button>
//                     </div>
//                 </div>
//                 {
//                     isFormVisible && <div className="row border" style={{ marginTop: '-20px ' }}>
//                         <div className="col-4 border mx-4 flex rounded-3 mt-4 mb-4">
//                             <br />
//                             <span className='' style={{ marginLeft: '50px' }}>Pieces Per Unit</span>
//                             <input type="text" style={{ marginLeft: '20px', width: '200px' }} />
//                             <br />
//                             <br />

//                             <span style={{ marginLeft: '39px' }}>Units Per Carton</span>
//                             <input type='text' style={{ marginLeft: '20px', width: '200px' }} />
//                             <br />
//                             <br />

//                             <span style={{ marginLeft: '42px' }}>CBM Per Carton</span>
//                             <input type="text" style={{ marginLeft: '20px', width: '200px' }} />
//                             <br />
//                             <br />

//                             <span style={{ marginLeft: '92px' }}>HS Code</span>
//                             <input type="text" style={{ marginLeft: '20px', width: '200px' }} />
//                             <br />
//                             <br />

//                         </div>


//                         <div className="col-4 border mt-4 mb-4 flex rounded-3 ">
//                             <br />

//                             <span className='' style={{ marginLeft: '50px' }}>Carton Length</span>
//                             <input type="text" style={{ marginLeft: '20px', width: '200px' }} />
//                             <br />
//                             <br />

//                             <span style={{ marginLeft: '43px' }}>Carton Breadth</span>
//                             <input type='text' style={{ marginLeft: '20px', width: '200px' }} />
//                             <br />
//                             <br />

//                             <span style={{ marginLeft: '50px' }}>Carton Height</span>
//                             <input type="text" style={{ marginLeft: '20px', width: '200px' }} />
//                             <br />
//                             <br />

//                         </div>


//                         <div className="col-4 mt-4 mb-5 flex rounded-3 border " style={{ width: '400px', marginLeft: '10px', height: '200px' }}>
//                             <br />
//                             <br />
//                             <span className='' style={{ marginLeft: '10px' }}>Gross Weight</span>
//                             <input type="text" style={{ marginLeft: '20px', width: '200px' }} />
//                             <br />
//                             <br />

//                             <span style={{ marginLeft: '25px' }}>Net Weight</span>
//                             <input type='text' style={{ marginLeft: '20px', width: '200px' }} />
//                             <br />
//                             <br />

//                             <input type="checkbox" name="" id="" style={{ marginLeft: '125px' }} />
//                             <span style={{ marginLeft: '10px' }}>Fair Packing</span> <br />



//                         </div>

//                     </div>
//                 }

//                 <br />
//                 {
//                     isFormVisibles && <div className="row mx-2">
//                         <div className="col-4 border flex rounded-3  ">
//                             <p style={{ marginTop: '-15px', border: 'none', color: '#00acff' }}>Stock Location</p>
//                             <br />
//                             <span className='' style={{ marginLeft: '52px' }}>Barcode 1 </span>
//                             <input type="text" style={{ marginLeft: '20px', width: '250px' }} />
//                             <br />
//                             <br />

//                             <span style={{ marginLeft: '52px' }}>Barcode 2</span>
//                             <input type='text' style={{ marginLeft: '25px', width: '250px' }} />
//                             <br />
//                             <br />

//                             <span style={{ marginLeft: '52px' }}>Barcode 3</span>
//                             <input type="text" style={{ marginLeft: '25px', width: '250px' }} />
//                             <br />
//                             <br />

//                             <span style={{ marginLeft: '72px' }}>Bundle</span>
//                             <input type="text" style={{ marginLeft: '27px', width: '250px' }} />
//                             <br />
//                             <p >Barcode</p>
//                             <br />

//                         </div>


//                         <div className="col-3 border flex rounded-3 mx-2 ">
//                             <p >Stock Levels</p>

//                             <br />

//                             <span className='' >Reorder Level</span>
//                             <input type="text"  />
//                             <br />
//                             <br />

//                             <span>Minimum Stock</span>
//                             <input type='text'  />
//                             <br />
//                             <br />

//                             <span >Maximum Stock</span>
//                             <input type="text"  />
//                             <br />
//                             <br />

//                             <span >Expiry Date</span>
//                             <input type="text"  />
//                             <br />
//                             <br />

//                         </div>


//                         <div className="col-4 border flex rounded-3 ">
//                             <p >Product Rate's (RS) - Store</p>

//                             <br />

//                             <span className='' >Product Stock</span>
//                             <input type="text" />
//                             <br />
//                             <br />

//                             <span >Avg Rate</span>
//                             <input type='text' />
//                             <br />
//                             <br />

//                             <span >Until Sale Value</span>
//                             <input type='text'  />
//                             <span >Until Purchase</span>
//                             <input type='text' />
//                             <br />
//                             <p >Rate</p>



//                             <span >Profit %</span>
//                             <input type='text' />
//                             <br /><br />




//                             <span >Discoun15%</span>
//                             <input type='text' />
//                             <br />
//                             <br />


//                         </div>

//                         <div className="col-3 border" >

//                             <span >Bundle</span>
//                             <input type="text"  />
//                             <p >Sale Rate</p>

//                             <span >Bundle</span>
//                             <input type="text"  />
//                             <p >Pur. Rate</p>

//                         </div>
//                         <div className=' border  mb-1'>
//                             <button ><i className="fa-solid fa-check"></i> Submit</button>
//                             <button ><i className="fa-solid fa-circle-xmark"></i> Cancel</button>
//                         </div>
//                     </div>
//                 }


//             </div>
//         </div>
//     )
// }
