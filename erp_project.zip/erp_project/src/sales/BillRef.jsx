import React, { useState } from 'react'

export default function BillRef() {

    const docs = [""];

    const [tableData, setTableData] = useState([
        ["1", "Item 1", "Description 1", "Unit 1", "10", "Remarks 1"],
        ["2", "Item 2", "Description 2", "Unit 2", "20", "Remarks 2"],
        // Add more initial rows as needed
      ]);
      const [selectedRows, setSelectedRows] = useState([]);
    
      const handleAddRow = () => {
        const newRow = ["", "", "", "", "", ""];
        setTableData([...tableData, newRow]);
      };
    
      const handleRemoveRow = () => {
        if (selectedRows.length === 0) {
          // No rows selected, delete the last row
          const updatedData = [...tableData];
          updatedData.pop();
          setTableData(updatedData);
        } else {
          // Rows are selected, remove selected rows
          const updatedData = tableData.filter((_, index) => !selectedRows.includes(index));
          setTableData(updatedData);
        }
        setSelectedRows([]);
      };
    
      const handleCheckboxChange = (rowIndex) => {
        if (selectedRows.includes(rowIndex)) {
          setSelectedRows(selectedRows.filter((row) => row !== rowIndex));
        } else {
          setSelectedRows([...selectedRows, rowIndex]);
        }
      };
    
      const handleCellChange = (event, rowIndex, colIndex) => {
        const updatedData = [...tableData];
        updatedData[rowIndex][colIndex] = event.target.value;
        setTableData(updatedData);
      };

  return (
    <div className="row border mt-5">
            <div className="col-3 border"></div>

            <div className="col-9 border">
                <br />
                <span>Party Name:</span>
                <input type="text" className='w-25' placeholder='Customer A - Local (122-001)' style={{border:'none',marginLeft:'170px'}}/> 
                <br /> <br />

                <span>New Reference</span>
                <input type="number" placeholder='0.00' className='w-25' style={{marginLeft:'150px'}}/>
                <br /> <br />

                <span>On-Account</span>
                <input type="number" placeholder='0.00' className='w-25' style={{marginLeft:'170px'}} />
                <br /> <br />

                <span>Amount Adjusted Against New Ref in Other Vouchers</span>
                <input type="text" placeholder='0.00' style={{border:'none',marginLeft:'30px'}}/>
                <br /> <br />

                <div className="border " style={{height:'130px',width:'400px',marginLeft:'780px', marginTop:'-100px'}}>
                    {/* <br /> */}
                    <h6>Amount To Be Adjusted</h6>
                    <span>Transaction Currency:</span>
                    <input type="text" />
                    <br />

                    <span>Base Currency:</span>
                    <input type="text" />
                    <br />

                    <span>Local Currency:</span>
                    <input type="text" />
                    <br />
                    <p style={{marginTop:'15px'}}>Balance New Ref Amount  <input style={{border:'none',marginLeft:'20px'}} type="text" placeholder='0.00' /></p>
                    
                </div>
                    
                <br /> <br />

<div><input type="submit" value={'Adjustment'} />

<select className='w-25' style={{ marginLeft: '35px' }}>
<option value="">Ducument No</option>
{docs.map((option, index) => (
  <option key={index} value={option}>
    {option}
  </option>
))}

</select>

<input type="text" placeholder='Search' /></div>

                <div>


                <span>Adjust Bills</span>
                    <select className='w-25' style={{ marginLeft: '35px' }}>
                <option value="">On Account</option>
                {docs.map((option, index) => (
                  <option key={index} value={option}>
                    {option}
                  </option>
                ))}

                </select>
                <span>Show Bills</span>

                {/* <span>Adjust Bills</span> */}
                    <select className='w-25' style={{ marginLeft: '35px' }}>
                <option value="">All</option>
                {docs.map((option, index) => (
                  <option key={index} value={option}>
                    {option}
                  </option>
                ))}

                </select>
                </div>

            <div style={{marginLeft:'680px'}}>


            <input type="sumit" value={'+'} style={{background:'#e6f7ff', border:'none', color:'#00acff',fontSize:'20px', marginLeft:'450px' , width:'40px', marginTop:'10px', paddingLeft:'10px'}} onClick={handleAddRow} />
          {/* <button >+</button> */}
          <input className='fw-bold' type='submit' value={' - '} style={{fontSize:'20px', background:'#e6f7ff', border:'none', marginBottom:'10px', marginLeft:'10px', width:'40px', color:'red'}} onClick={handleRemoveRow} />
    



                <table className='table' style={{ background:'white', width:'1200px', marginLeft:'-690px' }}>
        
        <thead>
          <tr className='border'>
            <th className='border' style={{background:'#e6f7ff'}}>Select</th>
            <th className='border ' style={{background:'#e6f7ff'}}></th>
            <th className='border ' style={{background:'#e6f7ff'}}>Doc No</th>
            <th className='border ' style={{background:'#e6f7ff'}}>Doc Date</th>
            <th className='border ' style={{background:'#e6f7ff'}}>Due Date</th>
            <th className='border ' style={{background:'#e6f7ff'}}>Currency</th>
            <th className='border ' style={{background:'#e6f7ff'}}>Original Amt</th>
          </tr>
        </thead>
        <tbody>
        {tableData.map((row, rowIndex) => (
          <tr key={rowIndex}>
            <td>
              <input
                style={{ border: 'none' }}
                type="checkbox"
                checked={selectedRows.includes(rowIndex)}
                onChange={() => handleCheckboxChange(rowIndex)}
              />
            </td>
            {row.map((cell, colIndex) => (
              <td key={colIndex}>
                <input
                  type="text"
                  value={cell}
                  onChange={(event) => handleCellChange(event, rowIndex, colIndex)}
                />
              </td>
            ))}
          </tr>
        ))}
      </tbody>
      </table>

      </div>
            </div>

           <div className="col-9 mx-5">

                    

           </div>
    </div>
  )
}
