import React, { useState } from 'react';
import Slide from '../components/Slide';
import '../sales/saleEnquiry.css';

export default function SalesQuotations() {

  const docs = ["opt1", "opt2"];

  const docs1 = ["opt1", "opt2", "opt3"];

  const docs2 = ["opt1", "opt2", "opt3", "opt4"];

  const [tableData, setTableData] = useState([
    ["1", "Item 1", "Unit 1", "10", "rate", "gross", "", "", "", "",""],
    ["2", "Item 2", "Unit 2", "20", "rate", "gross", "", "", "", "",""],
    // Add more initial rows as needed
  ]);
  const [selectedRows, setSelectedRows] = useState([]);

  const handleAddRow = () => {
    const newRow = ["", "", "", "", "", "", "", "", "", "", ""];
    setTableData([...tableData, newRow]);
  };

  const handleRemoveRow = () => {
    if (selectedRows.length === 0) {
      // No rows selected, delete the last row
      const updatedData = [...tableData];
      updatedData.pop();
      setTableData(updatedData);
    } else {
      // Rows are selected, remove selected rows
      const updatedData = tableData.filter((_, index) => !selectedRows.includes(index));
      setTableData(updatedData);
    }
    setSelectedRows([]);
  };

  const handleCheckboxChange = (rowIndex) => {
    if (selectedRows.includes(rowIndex)) {
      setSelectedRows(selectedRows.filter((row) => row !== rowIndex));
    } else {
      setSelectedRows([...selectedRows, rowIndex]);
    }
  };

  const handleCellChange = (event, rowIndex, colIndex) => {
    const updatedData = [...tableData];
    updatedData[rowIndex][colIndex] = event.target.value;
    setTableData(updatedData);
  };
  return (
    <>
      <div className='row'>
        <div className='col-3'>
          <Slide />
        </div>
        <div className='col-9 border'>
          <div className='row mt-5 ms-3  mb-2'>
            <h5 className='fs-4'>SALES/ <span className='text-muted fs-5'>SALES QUOTATION</span></h5>
            <hr />
            <div className='col-6 '>
              <label>Document No. </label>
              <select className=' rounded border-1 ms-5 sale-height mt-3' >
                <option value=""></option>
                {docs.map((option, index) => (
                  <option key={index} value={option}>
                    {option}
                  </option>
                ))}
              </select>
              <label>Customer Account</label>
              <select className=' rounded border-1 ms-3 sale-height mt-4'>
                <option value=""></option>
                {docs1.map((option, index) => (
                  <option key={index} value={option}>
                    {option}
                  </option>
                ))}
              </select>

              <label >Cost Center&nbsp;&nbsp;&nbsp;</label>
              <select className='mt-4 rounded border-1 sale-height ms-5'>
                <option value=""></option>
                {docs1.map((option, index) => (
                  <option key={index} value={option}>
                    {option}
                  </option>
                ))}
              </select>
             
              <label className=''>Enquiry Date</label><input type="date" className='sale-en mt-4 rounded border-1 ' />
              
            </div>
            <div className='col-6'>
              <label className='ms-4'>Date :&nbsp; &nbsp;</label><input type="date" className='sale-date mt-3 rounded border-1 ' />
             
              <label className='ms-4'>Sales Executive&nbsp;</label>
              <select className='mt-4 rounded border-1 sale-height ms-3 sale-height'>
                <option value=""></option>
                {docs1.map((option, index) => (
                  <option key={index} value={option}>
                    {option}
                  </option>
                ))}
              </select>
             
              <label className='ms-4'>Enquiry No.</label><input type="text" className='sale-height rounded border-1 mt-4 ms-5' />
              <label className='ms-4'>Narration&nbsp;&nbsp; &nbsp;</label><input type="text" className='sale-height rounded border-1 mt-4 ms-5' />
            </div>
          </div>
          <div className='btn-sub'>
            <input type="sumit" value={'+'} className='border-0 mt-4' style={{ background: '#e6f7ff', color: '#00acff', fontSize: '20px', marginLeft: '85%', width: '40px', paddingLeft: '10px' }} onClick={handleAddRow} />
            <input className='fw-bold' type='submit' value={' - '} style={{ fontSize: '20px', background: '#e6f7ff', border: 'none', marginBottom: '10px', marginLeft: '10px', width: '40px', color: 'red' }} onClick={handleRemoveRow} />
          </div>
          <div className='scrolltable'>
            <table className='table' >

              <thead>
                <tr className='border'>
                <th className='border' style={{background:'#e6f7ff'}}>Select</th>
                   <th className='border ' style={{background:'#e6f7ff'}}>S.No.</th>
                   <th className='border ' style={{background:'#e6f7ff'}}>Product</th>
                   {/* <th className='border ' style={{background:'#e6f7ff'}}>Description</th> */}
                   <th className='border ' style={{background:'#e6f7ff'}}>Units</th>
                   <th className='border ' style={{background:'#e6f7ff'}}>Quantity</th>
                   <th className='border ' style={{background:'#e6f7ff'}}>L-Local-Sales Enquiry </th>
                   <th className='border ' style={{background:'#e6f7ff'}}>Rate</th>
                   <th className='border ' style={{background:'#e6f7ff'}}>Gross</th>
                   <th className='border ' style={{background:'#e6f7ff'}}>Discount</th>
                   <th className='border ' style={{background:'#e6f7ff'}}>Discount Amount</th>
                   <th className='border ' style={{background:'#e6f7ff'}}>Taxable Value</th>
                </tr>
              </thead>
              <tbody>
                {tableData.map((row, rowIndex) => (
                  <tr key={rowIndex}>
                    <td>
                      <input
                        style={{ border: 'none' }}
                        type="checkbox"
                        checked={selectedRows.includes(rowIndex)}
                        onChange={() => handleCheckboxChange(rowIndex)}
                      />
                    </td>
                    {row.map((cell, colIndex) => (
                      <td key={colIndex}>
                        <input
                          type="text"
                          value={cell}
                          onChange={(event) => handleCellChange(event, rowIndex, colIndex)}
                        />
                      </td>
                    ))}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          <input type="text" placeholder='Net:' className='mt-4 w-100' />
          <button className='border-0  text-light mt-4 rounded ' style={{ background: '#00acff', marginLeft: '70%' }}><i class="fa-solid fa-check"></i>Submit</button>
          <button className='border-0  text-light mt-4 rounded ms-2' style={{ background: '#00acff' }}><i class="fa-solid fa-xmark"></i>Cancel</button>

        </div>
      </div>
    </>

    //     <div className="row border">

    //       <div className="col-2  border"></div>

    //       <div className="col-5">
    //         <br />
    //         <p className='mt-3 fw-bold' style={{ marginLeft: '' }}>Delivery Notes </p>
    //           <br />
    //         <hr style={{ marginTop: '-15px' }} />

    //         <span style={{ marginLeft: '' }}>Document No.</span>
    //         <select className='w-75' style={{ marginLeft: '55px', height:'30px' }}>
    //           <option value=""></option>
    //           {docs.map((option, index) => (
    //             <option key={index} value={option}>
    //               {option}
    //             </option>
    //           ))}

    //         </select>
    //         <br />
    //         <br />
    //         <span style={{ marginLeft: '' }}>Customer Account</span>
    //         <select className='w-75 ' style={{ marginLeft: '28px', height:'30px' }}>
    //           <option value=""></option>
    //           {docs1.map((option, index) => (
    //             <option key={index} value={option}>
    //               {option}
    //             </option>
    //           ))}
    //         </select>


    //         {/* <span style={{ marginLeft: '' }}>Raise Receipt</span>
    //         <input type="checkbox"  style={{ marginLeft: '65px' }} /> */}


    //         <br />
    //         <br />
    //         <span style={{ marginLeft: '' }}>Warehouse</span>
    //         <select className='w-75 ' style={{ marginLeft: '80px', height:'30px' }}>
    //           <option value=""></option>
    //           {docs1.map((option, index) => (
    //             <option key={index} value={option}>
    //               {option}
    //             </option>
    //           ))}
    //         </select>
    //         <br /><br />

    //         <span style={{ marginLeft: '' }}>Is IGST</span>
    //         <select className='w-75 ' style={{ marginLeft: '112px', height:'30px' }}>
    //           <option value=""></option>
    //           {docs1.map((option, index) => (
    //             <option key={index} value={option}>
    //               {option}
    //             </option>
    //           ))}
    //         </select>
    //         <br /><br />

    //         <span style={{ marginLeft: '', marginTop: '' }}>Enquiry Date</span>
    //         <input type="date" className='w-75' style={{ marginLeft: '69px' }} />

    //         <br /><br />
    //         <span style={{ marginLeft: '', marginTop: '' }}>Quotation Date</span>
    //         <input type="check" className='w-75' style={{ marginLeft: '52px' }} />


    //         <br /><br />
    //         <span style={{ marginLeft: '', marginTop: '' }}>PO Date</span>
    //         <input type="date" className='w-75' style={{ marginLeft: '102px' }} />

    //         <br /> <br /> 




    //         <br />
    //       </div>

    //       <div className="col-5">
    //         <br />
    //         <br />
    //         <hr style={{ marginTop: '41px', marginLeft: '-24px' }} />
    //         <span style={{ marginLeft: '', marginTop: '' }}>Date:</span>
    //         <input type="date" className='w-75' style={{ marginLeft: '90px' }} />

    //         <br /><br />
    //         <span style={{ marginLeft: '' }}>Cost Center </span>
    //         <select className='w-75 ' style={{ marginLeft: '40px', height:'30px' }}>
    //           <option value=""></option>
    //           {docs2.map((option, index) => (
    //             <option key={index} value={option}>
    //               {option}
    //             </option>
    //           ))}
    //         </select>
    //         <br />
    //         <br />

    //         <span style={{ marginLeft: '' }}>Place of Supply </span>
    //         <select className='w-75 ' style={{ marginLeft: '15px', height:'30px' }}>
    //           <option value=""></option>
    //           {docs2.map((option, index) => (
    //             <option key={index} value={option}>
    //               {option}
    //             </option>
    //           ))}
    //         </select>
    //         <br /><br />

    //         <span style={{ marginLeft: '', marginTop: '' }}>Enquiry No</span>
    //         <input type="text" className='w-75' style={{ marginLeft: '48px' }} />

    //         <br /><br />

    // <span style={{ marginLeft: '', marginTop: '' }}>Quotation No</span>
    // <input type="text" className='w-75' style={{ marginLeft: '30px' }} />

    // <br /><br />

    // <span style={{ marginLeft: '', marginTop: '' }}>PO No</span>
    // <input type="text" className='w-75' style={{ marginLeft: '81px' }} />

    //         <br /> <br />
    // <span style={{ marginLeft: '' }}> Narration </span>
    //         <input type="text" className='w-75' style={{ marginLeft: '55px' }} />
    //         <br /><br />
    //          <br />


    // <input type="sumit" value={'+'} style={{background:'#e6f7ff', border:'none', color:'#00acff',fontSize:'20px', marginLeft:'495px' , width:'40px', marginTop:'10px', paddingLeft:'10px'}} onClick={handleAddRow} />
    //           {/* <button >+</button> */}
    //           <input className='fw-bold' type='submit' value={' - '} style={{fontSize:'20px', background:'#e6f7ff', border:'none', marginBottom:'10px', marginLeft:'10px', width:'40px', color:'red'}} onClick={handleRemoveRow} />


    //         <table className='table' style={{ background:'white', width:'1200px', marginLeft:'-690px' }}>

    //           <thead>
    //             <tr className='border'>
    //               <th className='border' style={{background:'#e6f7ff'}}>Select</th>
    //               <th className='border ' style={{background:'#e6f7ff'}}>S.No.</th>
    //               <th className='border ' style={{background:'#e6f7ff'}}>Product</th>
    //               {/* <th className='border ' style={{background:'#e6f7ff'}}>Description</th> */}
    //               <th className='border ' style={{background:'#e6f7ff'}}>Units</th>
    //               <th className='border ' style={{background:'#e6f7ff'}}>Quantity</th>
    //               <th className='border ' style={{background:'#e6f7ff'}}>L-Local-Sales <br /> Enquiry </th>
    //               <th className='border ' style={{background:'#e6f7ff'}}>Rate</th>
    //               <th className='border ' style={{background:'#e6f7ff'}}>Gross</th>
    //               <th className='border ' style={{background:'#e6f7ff'}}>Discount</th>
    //               <th className='border ' style={{background:'#e6f7ff'}}>Discount Amount</th>
    //               <th className='border ' style={{background:'#e6f7ff'}}>Taxable Value</th>
    //             </tr>
    //           </thead>
    //           <tbody>
    //           {tableData.map((row, rowIndex) => (
    //             <tr key={rowIndex}>
    //               <td>
    //                 <input
    //                   style={{ border: 'none' }}
    //                   type="checkbox"
    //                   checked={selectedRows.includes(rowIndex)}
    //                   onChange={() => handleCheckboxChange(rowIndex)}
    //                 />
    //               </td>
    //               {row.map((cell, colIndex) => (
    //                 <td key={colIndex}>
    //                   <input
    //                     type="text"
    //                     value={cell}
    //                     onChange={(event) => handleCellChange(event, rowIndex, colIndex)}
    //                   />
    //                 </td>
    //               ))}
    //             </tr>
    //           ))}
    //         </tbody>
    //         </table>
    //         <br />

    //         <p className='border' style={{marginLeft:'-620px', width:'1190px'}}>Net:</p>
    //         <button style={{ background: '#00ACFF', color: 'white',  height: '40px', marginTop:'15px', marginLeft: '390px',border:'5px solid #00ACFF',borderRadius:'5px' }}><i className="fa-solid fa-check"></i> Submit</button>
    //                 <button style={{ background: '#00ACFF', color: 'white', height: '40px', margin: '10px',border:'5px solid #00ACFF',borderRadius:'5px' }}><i className="fa-solid fa-circle-xmark"></i> Cancel</button>





    //       </div>
    //     </div>
  );
}












































































// import React, { useState } from 'react';

// export default function SalesQuotations() {
 
//   const docs = ["opt1", "opt2"];

//   const docs1 = ["opt1", "opt2", "opt3"];

//   const docs2 = ["opt1", "opt2", "opt3", "opt4"];

//   const [tableData, setTableData] = useState([
//     ["1", "Item 1", "Description 1", "Unit 1", "10", "rate", "gross", "", "", ""],
//     ["2", "Item 2", "Description 2", "Unit 2", "20", "rate", "gross", "", "", ""],
//     // Add more initial rows as needed
//   ]);
//   const [selectedRows, setSelectedRows] = useState([]);

//   const handleAddRow = () => {
//     const newRow = ["", "", "", "", "", "", "", "" , "", "", ""];
//     setTableData([...tableData, newRow]);
//   };

//   const handleRemoveRow = () => {
//     if (selectedRows.length === 0) {
//       // No rows selected, delete the last row
//       const updatedData = [...tableData];
//       updatedData.pop();
//       setTableData(updatedData);
//     } else {
//       // Rows are selected, remove selected rows
//       const updatedData = tableData.filter((_, index) => !selectedRows.includes(index));
//       setTableData(updatedData);
//     }
//     setSelectedRows([]);
//   };

//   const handleCheckboxChange = (rowIndex) => {
//     if (selectedRows.includes(rowIndex)) {
//       setSelectedRows(selectedRows.filter((row) => row !== rowIndex));
//     } else {
//       setSelectedRows([...selectedRows, rowIndex]);
//     }
//   };

//   const handleCellChange = (event, rowIndex, colIndex) => {
//     const updatedData = [...tableData];
//     updatedData[rowIndex][colIndex] = event.target.value;
//     setTableData(updatedData);
//   };
//   return (

//     <div className="row border">

//       <div className="col-2  border"></div>

//       <div className="col-5">
//         <br />
//         <p className='mt-3 fw-bold' style={{ marginLeft: '' }}>SALES QUOTATIONS</p>
//           <br />
//         <hr style={{ marginTop: '-15px' }} />

//         <span style={{ marginLeft: '' }}>Document No.</span>
//         <select className='w-75' style={{ marginLeft: '55px' }}>
//           <option value=""></option>
//           {docs.map((option, index) => (
//             <option key={index} value={option}>
//               {option}
//             </option>
//           ))}

//         </select>
//         <br />
//         <br />
//         <span style={{ marginLeft: '' }}>Customer Account</span>
//         <select className='w-75 ' style={{ marginLeft: '28px' }}>
//           <option value=""></option>
//           {docs1.map((option, index) => (
//             <option key={index} value={option}>
//               {option}
//             </option>
//           ))}
//         </select>
        

//         {/* <span style={{ marginLeft: '' }}>Raise Receipt</span>
//         <input type="checkbox"  style={{ marginLeft: '65px' }} /> */}
        

//         <br />
//         <br />
//         <span style={{ marginLeft: '' }}>Cost Center</span>
//         <select className='w-75 ' style={{ marginLeft: '77px' }}>
//           <option value=""></option>
//           {docs1.map((option, index) => (
//             <option key={index} value={option}>
//               {option}
//             </option>
//           ))}
//         </select>
//         <br /><br />
//         <span style={{ marginLeft: '', marginTop: '' }}>Enquiry Date</span>
//         <input type="date" className='w-75' style={{ marginLeft: '69px' }} />
        
//         <br /> <br /> <br />
//       </div>

//       <div className="col-5">
//         <br />
//         <br />
//         <hr style={{ marginTop: '41px', marginLeft: '-24px' }} />
//         <span style={{ marginLeft: '', marginTop: '' }}>Date:</span>
//         <input type="date" className='w-75' style={{ marginLeft: '90px' }} />
       

//         <br /><br />
//         <span style={{ marginLeft: '' }}>Sales Executive</span>
//         <select className='w-75 ' style={{ marginLeft: '22px' }}>
//           <option value=""></option>
//           {docs2.map((option, index) => (
//             <option key={index} value={option}>
//               {option}
//             </option>
//           ))}
//         </select>
//         <br />
//         <br />

//         <span style={{ marginLeft: '', marginTop: '' }}>Enquiry No</span>
//         <input type="text" className='w-75' style={{ marginLeft: '50px' }} />


//         <br /><br />
//         <span style={{ marginLeft: '' }}> Narration </span>
//         <input type="text" className='w-75' style={{ marginLeft: '57px' }} />
//         <br /> <br /> <br />


// <input type="sumit" value={'+'} style={{background:'#e6f7ff', border:'none', color:'#00acff',fontSize:'20px', marginLeft:'495px' , width:'40px', marginTop:'10px', paddingLeft:'10px'}} onClick={handleAddRow} />
//           {/* <button >+</button> */}
//           <input className='fw-bold' type='submit' value={' - '} style={{fontSize:'20px', background:'#e6f7ff', border:'none', marginBottom:'10px', marginLeft:'10px', width:'40px', color:'red'}} onClick={handleRemoveRow} />
    

//         <table className='table' style={{ background:'white', width:'1200px', marginLeft:'-690px' }}>
        
//           <thead>
//             <tr className='border'>
//               <th className='border' style={{background:'#e6f7ff'}}>Select</th>
//               <th className='border ' style={{background:'#e6f7ff'}}>S.No.</th>
//               <th className='border ' style={{background:'#e6f7ff'}}>Product</th>
//               <th className='border ' style={{background:'#e6f7ff'}}>Units</th>
//               <th className='border ' style={{background:'#e6f7ff'}}>Quantity</th>
//               <th className='border ' style={{background:'#e6f7ff'}}>L-Local-Sales <br /> Enquiry </th>
//               <th className='border ' style={{background:'#e6f7ff'}}>Rate</th>
//               <th className='border ' style={{background:'#e6f7ff'}}>Gross</th>
//               <th className='border ' style={{background:'#e6f7ff'}}>Discount</th>
//               <th className='border ' style={{background:'#e6f7ff'}}>Discount Amount</th>
//               <th className='border ' style={{background:'#e6f7ff'}}>Taxable Value</th>
//             </tr>
//           </thead>
//           <tbody>
//           {tableData.map((row, rowIndex) => (
//             <tr key={rowIndex}>
//               <td>
//                 <input
//                   style={{ border: 'none' }}
//                   type="checkbox"
//                   checked={selectedRows.includes(rowIndex)}
//                   onChange={() => handleCheckboxChange(rowIndex)}
//                 />
//               </td>
//               {row.map((cell, colIndex) => (
//                 <td key={colIndex}>
//                   <input
//                     type="text"
//                     value={cell}
//                     onChange={(event) => handleCellChange(event, rowIndex, colIndex)}
//                   />
//                 </td>
//               ))}
//             </tr>
//           ))}
//         </tbody>
//         </table>
//         <br />

//         <p className='border' style={{marginLeft:'-620px', width:'1190px'}}>Net:</p>
//         <button style={{ background: '#00ACFF', color: 'white',  height: '40px', marginTop:'15px', marginLeft: '390px',border:'5px solid #00ACFF',borderRadius:'5px' }}><i className="fa-solid fa-check"></i> Submit</button>
//                 <button style={{ background: '#00ACFF', color: 'white', height: '40px', margin: '10px',border:'5px solid #00ACFF',borderRadius:'5px' }}><i className="fa-solid fa-circle-xmark"></i> Cancel</button>

        

        
          
//       </div>
//     </div>
//   );
// }





