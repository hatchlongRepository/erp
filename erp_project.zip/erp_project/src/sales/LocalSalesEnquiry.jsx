import React, { useState } from 'react';
import Slide from '../components/Slide';
import '../sales/saleEnquiry.css';

export default function LocalSalesEnquiry() {

  const docs = ["opt1", "opt2"];

  const docs1 = ["opt1", "opt2", "opt3"];

  const docs2 = ["opt1", "opt2", "opt3", "opt4"];

  const [tableData, setTableData] = useState([
    ["1", "Item 1", "Description 1", "Unit 1", "10", "Remarks 1"],
    ["2", "Item 2", "Description 2", "Unit 2", "20", "Remarks 2"],
    // Add more initial rows as needed
  ]);
  const [selectedRows, setSelectedRows] = useState([]);

  const handleAddRow = () => {
    const newRow = ["", "", "", "", "", ""];
    setTableData([...tableData, newRow]);
  };

  const handleRemoveRow = () => {
    if (selectedRows.length === 0) {
      // No rows selected, delete the last row
      const updatedData = [...tableData];
      updatedData.pop();
      setTableData(updatedData);
    } else {
      // Rows are selected, remove selected rows
      const updatedData = tableData.filter((_, index) => !selectedRows.includes(index));
      setTableData(updatedData);
    }
    setSelectedRows([]);
  };

  const handleCheckboxChange = (rowIndex) => {
    if (selectedRows.includes(rowIndex)) {
      setSelectedRows(selectedRows.filter((row) => row !== rowIndex));
    } else {
      setSelectedRows([...selectedRows, rowIndex]);
    }
  };

  const handleCellChange = (event, rowIndex, colIndex) => {
    const updatedData = [...tableData];
    updatedData[rowIndex][colIndex] = event.target.value;
    setTableData(updatedData);
  };
  return (

   
    <>
      <div className='row'>
        <div className='col-3'>
          <Slide />
        </div>
        <div className='col-9 border'>
          <div className='row mt-5 ms-3  mb-2'>
            <h5 className='fs-4'>SALES/ <span className='text-muted fs-5'>ADD SALES ENQUIRY</span></h5>
            <hr />
            <div className='col-6 '>
              <label>Document No. </label>
              <select className=' rounded border-1 ms-5 sale-height mt-3' >
                <option value=""></option>
                {docs.map((option, index) => (
                  <option key={index} value={option}>
                    {option}
                  </option>
                ))}
              </select>
              <label>Customer Account&nbsp;</label>
              <select className=' rounded border-1 ms-3 sale-height mt-4'>
                <option value=""></option>
                {docs1.map((option, index) => (
                  <option key={index} value={option}>
                    {option}
                  </option>
                ))}
              </select>
              <label >Raise Receipt&nbsp;  </label>
              <input type="checkbox" className='ms-5 mt-4' /><br />
              <label >Cost Center&nbsp;&nbsp;&nbsp;&nbsp;</label>
              <select className='mt-4 rounded border-1 sale-height ms-5'>
                <option value=""></option>
                {docs1.map((option, index) => (
                  <option key={index} value={option}>
                    {option}
                  </option>
                ))}
              </select>
            </div>
            <div className='col-6'>
              <label className='ms-4'>Date : &nbsp;</label><input type="date" className='sale-date mt-3 rounded border-1 ' />
              <label className='ms-4'>Update Stock&nbsp;</label>
              <input type="checkbox" className='ms-4 mt-4' /><br />
              <label className='ms-4'>Sales Executive&nbsp;</label>
              <select className='mt-4 rounded border-1 sale-height ms-2 sale-height'>
                <option value=""></option>
                {docs1.map((option, index) => (
                  <option key={index} value={option}>
                    {option}
                  </option>
                ))}
              </select>
              <label className='ms-4'>Narration&nbsp;&nbsp;&nbsp;</label><input type="text" className='sale-height rounded border-1 mt-4 ms-5' />
            </div>
          </div>
          <div className='btn-sub'>
            <input type="sumit" value={'+'} className='border-0 mt-4' style={{ background: '#e6f7ff', color: '#00acff', fontSize: '20px', marginLeft: '85%', width: '40px', paddingLeft: '10px' }} onClick={handleAddRow} />
            <input className='fw-bold' type='submit' value={' - '} style={{ fontSize: '20px', background: '#e6f7ff', border: 'none', marginBottom: '10px', marginLeft: '10px', width: '40px', color: 'red' }} onClick={handleRemoveRow} />
          </div>
          <div className='scrolltable'>
            <table className='table' >

              <thead>
                <tr className='border'>
                  <th className='border' style={{ background: '#e6f7ff' }}>Select</th>
                  <th className='border ' style={{ background: '#e6f7ff' }}>S.No.</th>
                  <th className='border ' style={{ background: '#e6f7ff' }}>Product</th>
                  <th className='border ' style={{ background: '#e6f7ff' }}>Description</th>
                  <th className='border ' style={{ background: '#e6f7ff' }}>Units</th>
                  <th className='border ' style={{ background: '#e6f7ff' }}>Quantity</th>
                  <th className='border ' style={{ background: '#e6f7ff' }}>Remark</th>
                </tr>
              </thead>
              <tbody>
                {tableData.map((row, rowIndex) => (
                  <tr key={rowIndex}>
                    <td>
                      <input
                        style={{ border: 'none' }}
                        type="checkbox"
                        checked={selectedRows.includes(rowIndex)}
                        onChange={() => handleCheckboxChange(rowIndex)}
                      />
                    </td>
                    {row.map((cell, colIndex) => (
                      <td key={colIndex}>
                        <input
                          type="text"
                          value={cell}
                          onChange={(event) => handleCellChange(event, rowIndex, colIndex)}
                        />
                      </td>
                    ))}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          <input type="text" placeholder='Net:' className='mt-4 w-100'/>
          <button className='border-0  text-light mt-4 rounded ' style={{background:'#00acff',marginLeft:'70%'}}><i class="fa-solid fa-check"></i>Submit</button>
          <button className='border-0  text-light mt-4 rounded ms-2' style={{background:'#00acff'}}><i class="fa-solid fa-xmark"></i>Cancel</button>
       
        </div>
      </div>
    </>
  );
}





