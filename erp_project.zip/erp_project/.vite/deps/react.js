import {
  require_react
} from "./chunk-2PA4WPI3.js";
import "./chunk-ROME4SDB.js";
export default require_react();
//# sourceMappingURL=react.js.map
